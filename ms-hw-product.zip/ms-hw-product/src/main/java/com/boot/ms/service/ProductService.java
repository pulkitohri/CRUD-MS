package com.boot.ms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.ms.entity.Product;
import com.boot.ms.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository repository;
	
	public List<Product> showAll() {
		return repository.findAll();
	}
	
	public Product addProduct(Product product) {
		return repository.save(product);
	}
	
	public List<Product> deleteProduct(int ProductId) {

		List<Product> list = null;
		repository.deleteById(ProductId);
		return list;
	}
	
	public List<Product> getAllProductByCategory(int CategoryId){
		return repository.findAllProductByCategory(CategoryId);
	}
	
}
