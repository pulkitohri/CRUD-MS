package com.boot.ms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.ms.entity.Category;
import com.boot.ms.repository.CategoryRepository;

@Service
public class CategoryService {

	@Autowired
	CategoryRepository repository;
	
	public List<Category>showAll(){
		return repository.findAll();
	}
	
	public Category addCategory(Category category) {
		return repository.save(category);
	}
	
	public List<Category> deleteCategory(int CategoryId) {

		List<Category> list = null;
		repository.deleteById(CategoryId);
		return list;
	}
	
	public Category updateCategory(Category category) {
		Category category2 = repository.findById(category.getCategoryId()).get();
		category2.setCategoryName(category.getCategoryName());
		return repository.save(category2);
	}
	
	public Category singleCategory(int CategoryId) {
		return repository.findById(CategoryId).orElse(null);
		
	}
	
}
