package com.boot.ms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.ms.entity.Product;
import com.boot.ms.model.Category;
import com.boot.ms.model.ProductCategoryResponse;
import com.boot.ms.service.FeignService;
import com.boot.ms.service.ProductService;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	ProductService service;
	
	@Autowired
	FeignService feignService;
	
	@GetMapping("/showAll")
	public List<Product> showProducts(){
		return service.showAll();
	}
	
	@PostMapping("/insert")
	public ResponseEntity<Product> addCategory(@RequestBody Product product){
		return new ResponseEntity<Product>(service.addProduct(product),HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{ProductId}")
	public List<Product> deleteProduct(@PathVariable int ProductId) {
		List<Product> list = service.deleteProduct(ProductId);
		return list;
	
	}
	
	@GetMapping("/getProductAndCategory")
	@CircuitBreaker(name="PRODUCT-MS",fallbackMethod = "callFallBack")
	public ResponseEntity<?> getAllProductByCategory(@PathVariable int CategoryId){
		ResponseEntity<?> responseEntity = null;
		Category category = feignService.getCategoryById(CategoryId);
		if ( category == null) {
			responseEntity = new ResponseEntity<String>("Not Found", HttpStatus.NOT_FOUND);
		}
		else
		{
			List <Product> productlist = service.getAllProductByCategory(CategoryId);
			ProductCategoryResponse response = new ProductCategoryResponse();
			response.setProducts(productlist);
			response.setCategory(category);
			responseEntity = new ResponseEntity<ProductCategoryResponse>(response, HttpStatus.OK);
		}
		return responseEntity;
		
	}
	
	public ResponseEntity<?> callFallBack(Exception exception) {
		return new ResponseEntity<String>("Service Is not available", HttpStatus.SERVICE_UNAVAILABLE);

	}
	
	
	
}
