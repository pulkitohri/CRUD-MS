package com.boot.ms.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.boot.ms.model.Category;

@FeignClient(value = "CATEGORY-MS")
public interface FeignService {

	@GetMapping("/category/get/{CategoryId}")
	public Category getCategoryById(@PathVariable int CategoryId);
}
