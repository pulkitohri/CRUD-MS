package com.boot.ms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.ms.entity.Category;
import com.boot.ms.service.CategoryService;

@RestController
@RequestMapping("/category")
public class CategoryController {
	@Autowired
	CategoryService service;
	
	@GetMapping("/getCategory")
	public List<Category> showAllData(){
		return service.showAll();
	}
	
	@PostMapping("/insert")
	public ResponseEntity<Category> addCategory(@RequestBody Category category){
		return new ResponseEntity<Category>(service.addCategory(category),HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{CategoryId}")
	public List<Category> deleteCategory(@PathVariable int CategoryId) {
		List<Category> list = service.deleteCategory(CategoryId);
		return list;
	
	}
	
	@PutMapping("/updateCategory")
	public Category updateCategory(@RequestBody Category category) {
		return service.updateCategory(category);
		
	}
	
	@GetMapping("/get/{CategoryId}")
	public ResponseEntity<?> singleCategory(@PathVariable int CategoryId) {
		Category category = service.singleCategory(CategoryId);
		ResponseEntity<?> responseEntity = null;
		if (category == null) {
			responseEntity = new ResponseEntity<String>("No Category found with the given id " + CategoryId,
					HttpStatus.SERVICE_UNAVAILABLE);
		} else {
			responseEntity = new ResponseEntity<Category>(service.singleCategory(CategoryId), HttpStatus.OK);
		}
		return responseEntity;
	}
	
	
	
	
	
	
}
