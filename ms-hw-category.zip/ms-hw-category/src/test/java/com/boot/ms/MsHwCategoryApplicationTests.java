package com.boot.ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsHwCategoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
